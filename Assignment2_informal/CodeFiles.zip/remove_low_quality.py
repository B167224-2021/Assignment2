#!/usr/local/bin/python3
import re
with open('protein_seq.fasta','r') as f1:
	with open('qualified.fasta','w') as f2:
		for line in f1:
			line= line.rstrip()
			if "LOW QUALITY" in line:
				continue
			elif line.startswith('>'):
				regex= re.compile('.*\[((.+?)\s+.*?)\].*')
				matches= regex.search(line)
				#species= matches[2]
				f2.write('%s\n'%line)
			else:
				f2.write("%s\n"%line)
