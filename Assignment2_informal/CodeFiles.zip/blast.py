#!/usr/local/bin/python3
import subprocess
import os
import shutil
from time import sleep
import re
from datetime import datetime
#Make a database with the initially retrieved data
subprocess.call("makeblastdb -in protein_seq.fasta -dbtype prot -out database",shell=True)
print("Database made.")
sleep(1)

#Choose the protein of interest
#This function lets the user to view the data before typing accession number.
def view_acc():
	while True:
		sleep(1)
		react= input("Please enter 'a' to view the aligned data, or enter 'i' to view all data before filtering for alignment.\n Enter 'q' to finish viewing.")
		if react=='a':
			subprocess.call("more aligned.fa",shell=True)
		elif react== 'i':
			subprocess.call("more qualified.fasta",shell=True)
		elif react== 'q':
			break
		else:
			print("Please enter a valid key.")

#This is the function for choosing accession.
def choose_acc():
	while True:
		acc=input("Please type the accession: ")
		print("This is your chosen accession: %s"%(acc))
		decision= input("Press y to confirm, or any other key to view data.")  #There is a chance to look back again.
		if decision!= 'y':
			view_acc()
		else:
			print("Confirmed.")
			return acc
			break

while  True:
	print("Choose one protein of interest and blast against the initially attained data.")
	sleep(1)
	print("You have to pick the sequence by typing the accession number.")
	sleep(1)
	print("And you may have a look at the data before typing.")
	view_acc()
	sleep(1)
	acc= choose_acc()
	command= "pullseq -i protein_seq.fasta -g {} > interest.fasta".format(acc)
	subprocess.call(command,shell=True)
	subprocess.call("blastp -db database -query interest.fasta > blastout.out",shell=True)

#Name the current output
	now= datetime.now().time()
	filename= "blastout%s.out"%(str(now))
	os.rename("./blastout.out","./{}".format(filename))
	print("The result is now in %s"%(filename))
	sleep(1)
	react= input("Please enter c if you like to blast another protein, or enter any other key to exit.")
	if react== 'c':
		print("Continue.")
		sleep(1)
	else:
		print("Returning to the central menu.")
		break
		
subprocess.call("./main_menu.py",shell=True)

