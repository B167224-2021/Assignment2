#!/usr/local/bin/python3
import os
import sys
import subprocess
from time import sleep
#Enter the protein family and organism of inerest, show the input values, users could decide whether they need to enter again
while True:
	protein_family = input("Please enter the protein family:\n\t")
	organism = input("Pleaase enter the organism of interest:\n\t")
	print("Will be searching for %s in %s"%(str(protein_family),str(organism)))
	sleep(1)
	a= input("Press 'y' to confirm, or any other key to enter again:\n\t")
	if a == 'y':
		print("Start searching... ")
		break
	else :
		print("...That's fine, let's type them again.")

#assign the esearch and efetch commands to get_prseq, which will work in bash
sleep(1)
print("This may take a while...")
get_prseq="esearch -db protein -query '{} AND {}[Organism] NOT PARTIAL'| efetch -format fasta > protein_seq.fasta".format(protein_family,organism)
subprocess.call(get_prseq,shell=True)
print("Searching complete.\nResults are kept in 'protein_seq.fasta'")
sleep(1)
print("Moving on to the next step of selecting data.")
subprocess.call("./qualified.py", shell=True)
