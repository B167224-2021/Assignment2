#!/usr/local/bin/python3
import subprocess
import sys
import re
from time import sleep

print("Performing sequence alignment...")
subprocess.call("clustalo -i ready_to_align.fasta -o aligned.fa --outfmt=fasta --guidetree-out=aligned.dnd --force",shell=True)
print("Aligned seqence is now in aligned.fa")
sleep(1)

#Define a function that counts the number of aligned residues, but failed for some reasons. It seems only counting 46 rsidues for each sequece even if I stripped '\n'. Maybe there is other problems.
#def count_residue(line):
#	count= 0
#	for i in range(len(line)):
#		if i != '-':
#			count+= 1
#	return count
#Calculate the numbers aligned residues for each species.
#score_dict={}
#with open("aligned.fa","r") as f:
#	for line in f:
#		line= line.rstrip()
#		i=(-1)
#		if line.startswith('>'):
#			#regex= re.compile('.*\[((.+?)\s+.*?)\].*')
#			species= re.search('>',line)
#		#	species= matches[1]
#			score_dict[species]= 0
#			i+= 1
#		else:
#			line=str(line)
#			line=line.strip('\n')
#			count= count_residue(line)
#			score_dict[list(score_dict.keys())[i]]=count	
#print(score_dict)

print("Preparing for plotting conservation levels.")
while True:
	sleep(1)
	winsize=input("\nPlease specify the window size. (Defult is 4)")
	graph= input("\nPlease enter the graph type. (Defult is x11)")
	plot="plotcon -sformat fasta aligned.fa -winsize {} -graph {}".format(winsize, graph)
	subprocess.call(plot,shell=True)
#Ask the user to decide whether to plot again or to move on.
	decision= input("To leave this step, please enter e. Or enter anyother key to set plotting parameters again.")
	if decision == 'e':
		print("Returning to the central menu.")
		sleep(1)
		break
	else:
		print("Preparing again.")
		sleep(1)

subprocess.call("./main_menu.py",shell=True)


