#!/usr/local/bin/python3
import sys
import subprocess
import re
from time import sleep
#Making a list of all species found and keep the repeated species. 
species_list=[]
with open("qualified.fasta","r") as f:
	for line in f:
		line= line.rstrip()
		if line.startswith('>'):
			regex= re.compile('.*\[((.+?)\s+.*?)\].*')
			matches= regex.search(line)
			species= matches[2]
			species_list.append(species)
		else:
			continue


#Present the frequency of species for the user to choose.
species_dict= {}
for i in species_list:
	species_dict[i]=0
#Count frequency
for i in species_list:
	count= 0
	for j in species_list:
		if i ==j:
			count+= 1
	species_dict[i]=count
species_dict= dict(sorted(species_dict.items(), key= lambda item: item[1], reverse=True))
print("Here is the list of genus sorted by the frequency(which is the number of results of this genus) in all protein sequences attained.\n")
sleep(2)
print(species_dict)


#This function create the dataset from the most frequent genus.
#The number of genus is decided by the user.
selected= [] #This is the list of genus selected by the user

def choose_top():
	while True:
		print("\nHow many genus from the most frequent would you like to in include?")
		sleep(1)
		choice= input("\nPlease type the number, or press zero to exit the programme.")
		if choice== 0:
			print("Thank you.")
			break
		elif int(choice)> len(species_dict):
			print("The number you entered is larger than the total number of genus.")
		else:
			for i in range(int(choice)):
				genus= list(species_dict.keys())[i]
				selected.append(genus)
			break
				#print(genus)
def choose_by_hand():
	while True:
		sleep(1)
		name= input("\nPlease type a name presented in the above list within a square bracket")
		print("Is this genus %s you would like to include?"%name)
		decide= input("Type y to confirm, or any other key to enter again.")	
		if decide=='y':
			exsistence=0   #If the name does not exist in species_dict, this value will remain 0, and will trigger a feedback
			for i in list(species_dict.keys()):
				if re.search(name,i):
					exsistence+= 1
			if exsistence==0:
				print("Sorry, this name is not found in the data, please enter again.")
			else:
				selected.append(name)	
choose_top()

sleep(1)
print("\nThese are the selected genuses")
sleep(1)
print(selected)

#I failed to use next() to get the next sequence of a selected species			
#Make a dict of all headers and sequences, then choose the data from the dictionary
qualified_dict={}			
with open("qualified.fasta","r") as f:
	i=0  #Use as the index to fill the values(sequence) to the headers(key)
	line=line.rstrip()
	for line in f:
		if line.startswith('>'):
			regex= re.compile('.*\[((.+?)\s+.*?)\].*')
			genus= regex.search(line)
			qualified_dict[line]=' '
			i+= 1  #'i' remembers the index of a header
		else:   
			line=line.strip('\n')  	
			qualified_dict[list(qualified_dict.keys())[i-1]]=line

with open("ready_for_align.fasta","w") as f:
	for i in selected:
		count=(-1)
		for j in list(qualified_dict.keys()):
			count+= 1
			if re.search(i,j):
				header= list(qualified_dict.keys())[count]
				seq= list(qualified_dict.values())[count]
				f.write('%s\n'%header)
				f.write('%s\n'%seq)
print("\nThe chosen dataset is now in ready_for_align.fasta")	
print("Preparing the next step before conservation analysis...")
subprocess.call("./conservation.py")					
