#!/usr/local/bin/python3
import subprocess
from time import sleep
import os
import shutil
#Show the number of protein marked as low quality, then ask the user to decide if they want to continue with these.
#The lines below will show the number of low quality sequences.
sleep(1)
with open('protein_seq.fasta', 'r') as f:
	count= 0
	for line in f.readlines():
		if 'LOW QUALITY' in line:
			count+= 1
	print("Detected %s results marked as LOW QUALITY"%(str(count)))

#A function of viewing low quality sequences
def quality_view():
	with open('low_quality.txt','w') as f1:
		with open('protein_seq.fasta','r') as f2:
			for line in f2:
				if "LOW QUALITY" in line:
					f1.write(line)
	with open('low_quality.txt','r') as f:
		print(f.read())


#Ask the user whether to remove low quality sequence
while True:
	react= input('Would you like to continue with LOW QUALITY PROTEIN?\nPress c to continue,\npress v to view the list of LOW QUALITY PROTEIN,\npress r to remove low quality sequences.')
	if react== 'c':
		print('Continue with low quality protein.')
		shutil.copy2('protein_seq.fasta','qualified.fasta')
		sleep(1)
		print("A copy of the current data has been made.")
		break
	elif react== 'v':
		quality_view()
	elif react== 'r':
		subprocess.call("./remove_low_quality.py",shell=True)
		print("The new dataset is now in the file qualified.fasta.")
		break
	else:
		print('Please enter a qualified value.')
sleep(1)
print("A primary dataset has been generated")
sleep(1)
subprocess.call("main_menu.py",shell=True)
